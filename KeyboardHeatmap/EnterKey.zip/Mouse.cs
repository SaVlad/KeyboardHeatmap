﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace KeyboardHeatmap {
	public partial class Mouse:UserControl {
		public event EventHandler LeftClick;
		public event EventHandler MiddleClick;
		public event EventHandler RightClick;

		private Point[] LeftButton = new Point[] {
			new Point(15, 80),
			new Point(20, 35),
			new Point(35, 15),
			new Point(50, 10),
			new Point(95, 10),
			new Point(95, 65),
			new Point(85, 70),
			new Point(80, 80),
			new Point(80, 95),
			new Point(45, 90),
			new Point(15, 80)
		};
		private Point[] RightButton = new Point[] {
			new Point(185, 80),
			new Point(180, 35),
			new Point(165, 15),
			new Point(150, 10),
			new Point(105, 10),
			new Point(105, 65),
			new Point(115, 70),
			new Point(120, 80),
			new Point(120, 95),
			new Point(155, 90),
			new Point(185, 80)
		};
		private Point[] MiddleButton = new Point[] {
			new Point(100, 70),
			new Point(110, 75),
			new Point(110, 120),
			new Point(100, 125),
			new Point(90, 120),
			new Point(90, 75),
			new Point(100, 70)
		};

		public Mouse() {
			InitializeComponent();
		}
		protected override void OnMouseMove(MouseEventArgs e) {
			if(IsInPolygon(LeftButton, e.Location) || IsInPolygon(RightButton, e.Location) || IsInPolygon(MiddleButton, e.Location))
				Cursor = Cursors.Hand;
			else
				Cursor = Cursors.Default;
		}
		protected override void OnMouseClick(MouseEventArgs e) {
			if(IsInPolygon(LeftButton, e.Location))
				LeftClick?.Invoke(this, new EventArgs());
			else if(IsInPolygon(RightButton, e.Location))
				RightClick?.Invoke(this, new EventArgs());
			else if(IsInPolygon(MiddleButton, e.Location))
				MiddleClick?.Invoke(this, new EventArgs());
		}
		protected override void OnPaint(PaintEventArgs e) {
			e.Graphics.DrawLines(Pens.Black, LeftButton);
			e.Graphics.DrawLines(Pens.Black, MiddleButton);
			e.Graphics.DrawLines(Pens.Black, RightButton);
		}

		public static bool IsInPolygon(Point[] poly, Point point) {
			var coef = poly.Skip(1).Select((p, i) => 
			(point.Y - poly[i].Y) * (p.X - poly[i].X) - (point.X - poly[i].X) * (p.Y - poly[i].Y)).ToList();
			if(coef.Any(p => p == 0))
				return true;
			for(int i = 1; i < coef.Count(); i++) {
				if(coef[i] * coef[i - 1] < 0)
					return false;
			}
			return true;
		}
	}
}
